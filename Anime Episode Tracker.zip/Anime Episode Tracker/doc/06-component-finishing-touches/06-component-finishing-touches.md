# Portfolio Part 6: Finishing Touches

- **Name**: Tian Tao
- **Dot Number**: tao.524
- **Due Date**: 4/19/2024
## Assignment Overview

By now, you should have an entire component implemented at all levels. For
example, you should have two interfaces, an abstract class, and a kernel
implementation.

Now, we want you to start producing your actual portfolio. To do that, you
need to do a few things first:

1. **You need to add testing**: tests can be written basically as soon as you
   have designed your interfaces. Of course, because of how many changes your
   design has probably had up to this point, writing tests that early may lead
   to a lot of rework. Therefore, there is no better time to start testing than
   now that you have something more concrete.
2. **You need to share some use cases**: while having an API is useful, it's
   not always clear how and why someone would use it. Therefore, you should
   probably replicate some of the proof-of-concept work you did previously
   using your complete component.
3. **You need to publish your work**: if you haven't yet already, now would
   be a good time to publish your component to a public repo like GitHub.

These are the three main tasks we want you to complete to round out your
portfolio project. However, there are tons of ways to take your work to the next
level, such as:

1. **Publish your documentation**: one of the perks of using JUnit is that you
   can directly convert all those comments you made in your code to HTML
   files that can be hosted as Java documentation. How do you think the OSU
   API works?
2. **Start a CI pipeline**: it's very likely that you won't touch your component
   again after this class. That said, maybe you want to actual publish your
   component to a dependency manager like Maven. If so, it's a good idea to
   setup some automated testing and deployment through "Continuous Integration."
   GitHub Actions is a common tool for this, so why not look into it?
3. **Track version history**: in the world of software development, it's very
   important that you version your API with a version number. There are many
   different techniques for versioning software, but a date-based system is
   pretty easy. If you release your component on a particular date, use that
   date as the version number. Alternatively, you can make use of other
   techniques like semantic versioning.

Many of these additional techniques are somewhat out of the scope of this
course, but just knowing about them could set you up for long term success.

## Assignment Checklist

Because these documents are long and full of text, you will be supplied with
a quick overview of what you need to do to get the assignment done as follows:

### Getting Started Tasks

- [ ] I have added my name to the top of this document
- [ ] I have added my dot number to the top of this document
- [ ] I have added the due date to the top of this document
- [ ] I have read the assignment overview in the "Assignment Overview" section
- [ ] I have read the assignment learning objectives in the "Assignment Learning Objectives" section
- [ ] I have read the assignment rubric in the "Assignment Rubric" section
- [ ] I have read this checklist

### Ongoing Tasks

- [ ] I have shared my reflection in the "Pre-Assignment" section
- [ ] I have created a test file for my kernel implementation
  - [ ] I have created a new Java file in `test`
  - [ ] I have exhaustively tested all of the kernel methods
  - [ ] I am aware that I cannot test my component against a reference implementation
- [ ] I have created a test file for my abstract class
  - [ ] I have created a new Java file in `test`
  - [ ] I have exhaustively tested all of the secondary methods
  - [ ] I am aware that I cannot test my component against a reference implementation
- [ ] I have create a code sample demonstrating a use case of my component
  - [ ] I have created a new Java file in `src`
  - [ ] I have imported and used my component in this file
- [ ] I have create another qualitatively different code sample demonstrating a use case of my component
  - [ ] I have created a new Java file in `src`
  - [ ] I have imported and used my component in this file
- [ ] I have published my project to an open-source remote repository
  - [ ] I have ensured that my repository is public
  - [ ] I know the project url (e.g., https://github.com/TheRenegadeCoder/sample-programs)

### Submission Tasks

- [ ] I have shared assignment feedback in the "Assignment Feedback" section
- [ ] I have converted this document to a PDF
- [ ] I compressed my project to a `.zip` file
- [ ] I am prepared to submit the PDF, the zip, and the link to the remote repo to Carmen
- [ ] I am prepared to give my peers feedback on their ideas

## Assignment Learning Objectives

Without learning objectives, there really is no clear reason why a particular
assessment or activity exists. Therefore, to be completely transparent, here is
what we're hoping you will learn through this particular aspect of the portfolio
project. Specifically, students should be able to:

1. Design a test plan for a software sequence component
2. Provide example use cases of a software sequence component
3. Use version control software to share a repository of code
4. Reflect on the software development process and the individual's own growth

## Assignment Rubric

Again, to be completely transparent, most of the portfolio project, except the
final submission, is designed as a formative assessment. Formative assessments
are meant to provide ongoing feedback in the learning process. Therefore,
the rubric is designed to assess the learning objectives *directly* in a way
that is low stakes—meaning you shouldn't have to worry about the grade. Just
do good work.

1. (15 points) All component methods must be tested including the Standard,
   kernel, and secondary methods. The format of testing will be different from
   the style used in the course because it is unlikely that you will have an
   existing component to test against (more on this below).
2. (15 points) There must be at least two different sample codes provided that
   show how the component might be used. For example, consider how `XMLTree`
   was used to create the `RSSReader` and the `RSSAggregator`. There is no
   expectation that you provide samples to this much depth, but two files
   with at least a main method would be excellent.
3. (5 points) The complete package (and ideally just the entire portfolio
   project directly) must be committed to some open-source software repository,
   such as GitHub. Appropriate efforts should be made to make the remote
   repository easy to navigate and explore, such as by overwriting the root
   README with details about your project.
4. (15 points) As you work through these finishing touches, take a moment to
   reflect on the software development process. There are reflection prompts
   below. You should also reflect on your growth as a developer and share
   details about what you've learned.

## Pre-Assignment Tasks

Now that you have created a software component from scratch, it's time to
reflect on that process as well as take some time to think about your
growth as a developer. Below, you will find a series of reflection prompts.
Take some time to fill them out honestly.

### Software Development

> A common gripe that students express is how much they feel the work they do
> in class fails to map to the real world. Now that you've had a chance to
> complete the portfolio project, how much better (or worse) do you think you
> understand software development and why?

<!-- TODO: discuss -->
Completing the portfolio project has significantly enhanced my understanding 
of real-world software development. The hands-on experience of designing, 
implementing, and documenting a software solution provided a clear 
perspective on the complexities and demands of actual development tasks. 
It bridged the gap between theoretical knowledge and practical application, 
illustrating the importance of clear planning, robust coding practices, and 
open communication within the community. This project highlighted how 
skills learned in class can be effectively applied to solve complex 
problems and create meaningful, maintainable software, making the 
educational process feel more relevant and directly connected to industry practices.

> Also, did the portfolio project surface any gaps in your own knowledge of
> software development. If so, what are those gaps and how did you address them?

<!-- TODO: discuss -->
The portfolio project revealed gaps in my knowledge, particularly 
in areas of advanced data structure management and optimization 
techniques. I realized the importance of deeper understanding 
in handling complex relationships within data, like managing and 
searching through nested structures efficiently. To address these 
gaps, I sought out additional resources such as online tutorials, 
documentation, and community forums. Engaging with more experienced developers 
through code reviews and discussions on platforms like Stack Overflow and GitHub 
also provided practical insights and solutions. This proactive approach not 
only filled my knowledge gaps but also enhanced my problem-solving skills and coding proficiency.

> Finally, as a part of completing the portfolio project, to what extent has
> your perspective of software development changed, if at all? In other words,
> is software development something you still enjoy? If not, why not?

<!-- TODO: discuss -->
Completing the portfolio project has positively reinforced my passion for software 
development. It has expanded my perspective on the creative and iterative 
nature of building software. The project underscored the satisfaction of solving 
real-world problems and the joy of bringing ideas to life through code. 
Witnessing a project evolve from a simple concept to a functional application 
has been incredibly rewarding. It highlighted the impact that well-crafted 
software can have, both on a personal level and within a broader community. T
his experience has deepened my enjoyment and commitment to pursuing a career 
in software development, eager to tackle new challenges and continue learning

### Personal Growth

> One of the challenges of completing the portfolio project is picking up a lot
> of skills on your own. Some of these skills are, of course, software skills.
> However, there are plenty of other skills you may have picked up through
> this process. Therefore, the first question is what skills did you pick up
> through this process?
>
> Throughout the portfolio project, I acquired several valuable skills 
> beyond software development. Time management emerged as crucial, learning 
> to efficiently allocate time to different phases of the project. Critical 
> thinking was sharpened by troubleshooting and refining the application. 
> Communication skills improved as I engaged with online communities for 
> feedback and support. Adaptability was key in responding to unexpected 
> challenges and incorporating new tools and libraries. Finally, 
> documentation skills were honed, as clear, concise, and useful 
> documentation is essential for both current understanding and 
> future maintenance. These skills enhanced my holistic approach 
> to project management and execution.

<!-- TODO: discuss -->
Reflecting on the software development process is crucial for both personal growth and the 
improvement of project outcomes. Over the course of developing the AnimeEpisodeTracker, 
several lessons have become evident, significantly enhancing my perspective and skills as a developer.

1. Importance of Design Before Coding: Spending time on design before diving into coding proved invaluable. By outlining the data structures and functionalities needed (e.g., using Map for series and episodes, and pairs of NaturalNumber for episode details), I could focus on implementing features without constant rework. This upfront planning minimized bugs and made the code more maintainable.
   
I learned the significant role that thorough pre-coding design plays in software development. 
By mapping out data structures and functionalities early, I minimized the need for mid-course 
corrections, which streamlined the development process and reduced errors. This approach not 
only made the actual coding more efficient but also increased the maintainability and 
scalability of the application.

2. Documentation and Clean Code Practices: Documenting the code and maintaining clean coding practices made the project more understandable not just to others, but also to myself when revisiting sections after some time. Effective comments and a well-maintained README are as important as the code itself for long-term project success.

The focus on maintaining clean code and comprehensive documentation taught me the value 
of clarity and simplicity in programming. Good documentation and clear code practices 
make the project accessible not only to collaborators but also useful when revisiting 
the project after some time. This approach facilitates easier updates, debugging, and 
scalability.

3. Learning Through Challenges: Implementing features like episode tracking and rating updates, and ensuring data integrity through methods like createNewRep for deep copying, were challenging but greatly improved my problem-solving skills. These challenges pushed me to explore and learn more about Java’s capabilities and best practices.

Tackling the specific challenges of feature implementation and data integrity exposed me 
to advanced aspects of Java and software architecture. It underscored the importance of 
continuous learning and adapting to overcome obstacles. These experiences enhanced my 
problem-solving skills and deepened my understanding of building robust and efficient systems.

4. Community Feedback and Open Source Contribution: Preparing the project for an open-source platform like GitHub emphasized the importance of community in software development. Writing clear instructions for installation, usage, and contribution invites collaboration, which can lead to better software solutions and innovation.

Engaging with the community through open source contributions highlighted the benefits of collaborative development. 
This experience showed me how diverse insights and peer feedback can drive innovation, improve software quality, 
and foster a supportive ecosystem for developers. It also emphasized the importance of clear communication in 
making software projects accessible and contributable by others.

Each of these reflections not only highlights key takeaways from this project but also underscores the continuous learning journey in software development. This project has certainly expanded my technical skills, especially in Java, and has grown my appreciation for the collaborative nature of building software.

> The follow-up question is: could you rephrase these skills you picked up
> as bullet points that you could put on a resume? Try it below.

<!-- TODO: discuss -->

Pre-Coding Design Proficiency: Demonstrated capability in early-stage project planning 
and data structure design, leading to streamlined development and minimized bugs.
Documentation and Code Quality: Developed and maintained clear, concise documentation and code, 
enhancing long-term project maintainability and accessibility.
Problem-Solving in Software Development: Enhanced problem-solving abilities through 
tackling complex programming challenges, optimizing feature implementations, 
and ensuring data integrity.Open Source Community Engagement: Actively participated in 
open-source projects, contributing to community-driven development and gaining 
experience in collaborative software creation.

> Next, how has working on this project affected your career trajectory?
> In other words, do you now hate the topic you picked? Or, are you even more
> interested in it? Both outcomes are valuable to your personal development.

Working on the AnimeEpisodeTracker project has positively impacted my career 
trajectory by significantly deepening my interest in software development. 
The project was both challenging and rewarding, reinforcing my passion for 
coding and problem-solving. Engaging with complex data structures and user 
interface design was particularly enlightening, pushing me to refine my 
skills in these areas. This experience has motivated me to pursue more 
ambitious projects and consider specializing in software architecture or 
user experience design. Far from hating the topic, I've grown more 
enthusiastic about its potential and look forward to further exploring 
this field.

<!-- TODO: discuss -->

> Finally, consider the skills you've picked up and your current career
> trajectory. What are some things you could do to continue on your
> career trajectory? Also, who are some mentors you could contact to help
> you stay on your path?

To continue advancing my career trajectory in software development, 
I plan to undertake further specialized training in advanced programming 
techniques and software architecture. Engaging in more complex projects 
and contributing to open-source communities will also be crucial. 
Additionally, maintaining a proactive learning mindset and staying updated 
with industry trends will help. For mentorship, I aim to connect with 
experienced developers from well-regarded software companies through 
LinkedIn and local tech meetups. Joining professional organizations 
like ACM or IEEE could also provide access to mentorship programs 
and valuable industry contacts to guide and accelerate my career 
development.

<!-- TODO: discuss -->

## Assignment Tasks

Your primary task for this assignment is to polish up your code and get it
ready to publish. To do that, you are being tasked with testing all of your
existing code. You are also being tasked with coming up with at least two
samples of your component being used for something. When all is said and done,
you will publish your component to an open-source repository of your choosing.

### Testing

As a part of testing your code, you will need to create a couple test files
in the `test` directory. One of the files will be the JUnit test file for the
kernel. Meanwhile, the other file will be the JUnit test file for the abstract
class.

Unlike throughout the semester, testing will not involve testing against
a reference implementation. As a result, testing is a bit messier and will
involve calling kernel methods to check state. For example, here is a test
case for one of the getters in Point3D:

```java
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AnimeEpisodeTrackerTest {
    
    private AnimeEpisodeTracker tracker;

    @Before
    public void setUp() {
        tracker = new AnimeEpisodeTracker();
    }

    @Test
    public void testCheckIfWatchedNoSeries() {
        assertFalse(tracker.checkIfWatched("NonExistent", 1));
    }

    @Test
    public void testCheckIfWatchedNoEpisode() {
        tracker.setEpisodeRating("One Piece", 1, 8);
        assertFalse(tracker.checkIfWatched("One Piece", 2));
    }

    @Test
    public void testCheckIfWatchedExists() {
        tracker.setEpisodeRating("Naruto", 1, 7);
        assertTrue(tracker.checkIfWatched("Naruto", 1));
    }

    @Test
    public void testSetEpisodeRatingNewSeries() {
        tracker.setEpisodeRating("Bleach", 1, 9);
        assertTrue(tracker.checkIfWatched("Bleach", 1));
    }

    @Test
    public void testUpdateEpisodeRating() {
        tracker.setEpisodeRating("Attack on Titan", 1, 7);
        tracker.setEpisodeRating("Attack on Titan", 1, 8);
        assertEquals(8, tracker.seriesMap.lookup("Attack on Titan").get(0).value().toInt());
    }

    @Test
    public void testGetAllSeriesNamesEmpty() {
        assertTrue(tracker.getAllSeriesNames().isEmpty());
    }

    @Test
    public void testGetAllSeriesNamesMultiple() {
        tracker.setEpisodeRating("DBZ", 1, 7);
        tracker.setEpisodeRating("Tokyo Ghoul", 1, 8);
        Sequence<String> names = tracker.getAllSeriesNames();
        assertTrue(names.contains("DBZ") && names.contains("Tokyo Ghoul"));
    }

    @Test
    public void testCreateNewRep() {
        tracker.setEpisodeRating("Jujutsu Kaisen", 1, 8);
        AnimeEpisodeTracker newTracker = tracker.createNewRep();
        newTracker.setEpisodeRating("Jujutsu Kaisen", 2, 9);
        assertFalse(tracker.checkIfWatched("Jujutsu Kaisen", 2));
        assertEquals(9, newTracker.seriesMap.lookup("Jujutsu Kaisen").get(1).value().toInt());
    }
}

```

### Use Cases

Another requirement to finish the project is to provide a couple of use cases
for your component. To do that, the only expectation is that you generate
two Java files in `src` with example code using your component either as part of
the representation of some other proof-of-concept component or directly in
`main`. For instance, the following class would be a extremely minimal example
of how Point3D might be used as part of a representation:

```java
import components.map.Map;
import components.map.Map1L;
import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.sequence.Sequence;
import components.sequence.Sequence1L;

public class AnimeRatingUpdater {

    private AnimeEpisodeTracker tracker;

    public AnimeRatingUpdater() {
        tracker = new AnimeEpisodeTracker();
    }

    public void updateRating(String seriesName, int episodeNumber, int newRating) {
        if (tracker.checkIfWatched(seriesName, episodeNumber)) {
            tracker.setEpisodeRating(seriesName, episodeNumber, newRating);
            System.out.println("Updated rating for " + seriesName + " Episode " + episodeNumber + " to " + newRating);
        } else {
            System.out.println(seriesName + " Episode " + episodeNumber + " has not been watched yet.");
        }
    }

    public static void main(String[] args) {
        AnimeRatingUpdater updater = new AnimeRatingUpdater();
        updater.updateRating("One Punch Man", 1, 10);
        updater.updateRating("One Punch Man", 2, 9);  // Assume episode 2 has not been watched yet
    }
}


import components.map.Map;
import components.map.Map1L;
import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.sequence.Sequence;
import components.sequence.Sequence1L;

public class AnimeWatchlistManager {

    private AnimeEpisodeTracker tracker;

    public AnimeWatchlistManager() {
        tracker = new AnimeEpisodeTracker();
    }

    public void addSeries(String seriesName, int episodeNumber, int rating) {
        tracker.setEpisodeRating(seriesName, episodeNumber, rating);
    }

    public void printWatchlist() {
        Sequence<String> seriesNames = tracker.getAllSeriesNames();
        System.out.println("Anime Watchlist:");
        for (String name : seriesNames) {
            System.out.println("Series: " + name);
        }
    }

    public static void main(String[] args) {
        AnimeWatchlistManager manager = new AnimeWatchlistManager();
        manager.addSeries("My Hero Academia", 1, 8);
        manager.addSeries("My Hero Academia", 2, 9);
        manager.addSeries("Demon Slayer", 1, 10);
        manager.addSeries("Steins Gate", 1, 10);

        manager.printWatchlist();
    }
}

```

### Publishing

Hopefully, you've already been working out of version control software this
entire semester. However, if you have not, the last step would be getting
the project committed to an open-source repository, such as GitHub. Before
submission, I would recommend that your repo looks something like the following:

```
│   .gitattributes
│   .gitignore
│   LICENSE
│   README.md
│
├───.vscode
│       extensions.json
│       osu-cse-checkstyle-config.xml
│       osu-cse-formatter.xml
│       settings.json
│
├───doc
│   │   README.md
│   │
│   ├───01-component-brainstorming
│   │       01-component-brainstorming.md
│   │
│   ├───02-component-proof-of-concept
│   │       02-component-proof-of-concept.md
│   │
│   ├───03-component-interfaces
│   │       03-component-interfaces.md
│   │
│   ├───04-component-abstract-class
│   │       04-component-abstract-classes.md
│   │
│   ├───05-component-kernel-implementation
│   │       05-component-kernel-implementation.md
│   │
│   └───06-component-finishing-touches
│           06-component-finishing-touches.md
│
├───lib
│       components.jar
│       hamcrest-core-1.3.jar
│       junit-4.13.2.jar
│       README.md
│
├───src
│   │   Point3DDemo.java
│   │   README.md
│   │   Square.java
│   │
│   └───components
│       └───geometry
│           └───point
│                   Point3D.java
│                   Point3D1.java
│                   Point3DKernel.java
│                   Point3DSecondary.java
│
└───test
    │   README.md
    │
    └───components
        └───geometry
            └───point
                    Point3D1Test.java
                    Point3DTest.java
```

There is no correct directory structure, but something like this will make it
easier for others to browse.

At any rate, once you're ready to commit, I would run a `git init` from the
portfolio root. Then, you can make use of whatever tools you want to get the
code to your remote server of choice. For example, you might follow up the
`git init` with a `git add .` and `git commit -m "Finalized my project"`.
At that point, you might use a tool like GitHub desktop to publish the repo
for you to GitHub. Otherwise, you have to do a bit more manual labor. In any
case, I trust that you can figure it out!

## Post-Assignment Tasks

The following sections detail everything that you should do once you've
completed the assignment.

### Submission

If you have completed the assignment using this template, we recommend that you
convert it to a PDF before submission. If you're not sure how, check out
this [Markdown to PDF guide][markdown-to-pdf-guide]. However, PDFs should be
created for you automatically every time you save, so just double check that
all your work is there before submitting.

Unlike before, there is no requirement that you submit any code in PDFs on
Carmen. Instead, you should submit the URL to the remote repository for your
project. You should also upload the zip of your code alongside the PDF of
this assignment. If you want feedback, your best bet is to use GitHub, so I
can open issues related to your code directly.

### Peer Review

Following the completion of this assignment, you will be assigned three
students' component abstract classes for review. Please do not spend a ton of
time on your reviews, **perhaps 10-15 minutes each**. Your job during the peer
review process is to help your peers work through the logic of their implementations
and identify gaps in their use of design-by-contract (i.e., forgetting checks
for preconditions). If something seems wrong to you, it's probably a good hunch,
so make sure to point it out.

When reviewing your peers' assignments, please treat them with respect. We
recommend using the following feedback rubric to ensure that your feedback is
both helpful and respectful (you may want to render the markdown as HTML or a
PDF to read this rubric as a table).

| Criteria of Constructive Feedback | Missing                                                                                                                           | Developing                                                                                                                                                                                                                                | Meeting                                                                                                                                                               |
| --------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Specific                          | All feedback is general (not specific)                                                                                            | Some (but not all) feedback is specific and some examples may be provided.                                                                                                                                                                | All feedback is specific, with examples provided where possible                                                                                                       |
| Actionable                        | None of the feedback provides actionable items or suggestions for improvement                                                     | Some feedback provides suggestions for improvement, while some do not                                                                                                                                                                     | All (or nearly all) feedback is actionable; most criticisms are followed by suggestions for improvement                                                               |
| Prioritized                       | Feedback provides only major or minor concerns, but not both. Major and minar concerns are not labeled or feedback is unorganized | Feedback provides both major and minor concerns, but it is not clear which is which and/or the feedback is not as well organized as it could be                                                                                           | Feedback clearly labels major and minor concerns. Feedback is organized in a way that allows the reader to easily understand which points to prioritize in a revision |
| Balanced                          | Feedback describes either strengths or areas of improvement, but not both                                                         | Feedback describes both strengths and areas for improvement, but it is more heavily weighted towards one or the other, and/or descusses both but does not clearly identify which part of the feedback is a strength/area for improvement  | Feedback provides balanced discussion of the document's strengths and areas for improvement. It is clear which piece of feedback is which                             |
| Tactful                           | Overall tone and language are not appropriate (e.g., not considerate, could be interpreted as personal criticism or attack)       | Overall feedback tone and language are general positive, tactul, and non-threatening, but one or more feedback comments could be interpretted as not tactful and/or feedback leans toward personal criticism, not focused on the document | Feedback tone and language are positive, tactful, and non-threatening. Feedback addesses the document, not the writer                                                 |

### Assignment Feedback

> Now that you've had a chance to complete the assignment, is there anything you
> would like to say about the assignment? For example, are there any resources
> that could help you complete this assignment? Feel free to use the feedback
> rubric above when reviewing this assignment.

<!-- TODO: share your feedback here -->

[markdown-to-pdf-guide]: https://therenegadecoder.com/blog/how-to-convert-markdown-to-a-pdf-3-quick-solutions/
