/*
 * Anime Episode Tracker Secondary
 * /**
 * Tracks anime series and episodes with ratings.
 *
 * Uses a map where the key is the series name and the value is a list of pairs of episode numbers and ratings.
 *
 *
 * Representation: A Map<String, List<Pair<NaturalNumber, NaturalNumber>>> is used to represent the tracking of anime series.
 * Each series is identified by a unique String (series name) and is associated with a List of Pairs.
 * Each Pair consists of two NaturalNumbers, where the key represents the episode number and the value represents the episode's rating.
 *
 * Convention: A valid configuration is one where each series name in the map is unique and each episode number within a series' list is unique.
 * The list for a series may be empty, indicating no episodes have been watched or rated yet.
 *
 * Correspondence: The map represents the entire collection of anime series being tracked.
 * The keys of the map correspond to the names of the anime series, and the values (lists of pairs) correspond to the episodes watched, along with their ratings.
 *
 * Kernel Methods: checkIfWatched, setEpisodeRating, getAllSeriesNames, createNewRep
 * Standard Methods: toString, equals, hashCode
 */

import components.map.Map;
import components.map.Map1L;
import components.sequence.Sequence;
import components.sequence.Sequence1L;
import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.list.List;
import components.list.List1L;


public class AnimeEpisodeTracker {

    private Map<String, List<Pair<NaturalNumber, NaturalNumber>>> seriesMap;

    public AnimeEpisodeTracker() {
        this.seriesMap = new Map1L<>();
    }

    /**
     * Checks if the specified episode of a series has been watched.
     */
    protected boolean checkIfWatched(String seriesName, int episodeNumber) {
        if (!this.seriesMap.hasKey(seriesName)) {
            return false;
        }
        List<Pair<NaturalNumber, NaturalNumber>> episodes = this.seriesMap.lookup(seriesName);
        return episodes.stream().anyMatch(e -> e.key().toInt() == episodeNumber);
    }

    /**
     * Sets the rating for a specific episode of a series.
     */
    protected void setEpisodeRating(String seriesName, int episodeNumber, int rating) {
        if (!this.seriesMap.hasKey(seriesName)) {
            this.seriesMap.add(seriesName, new List1L<>());
        }
        List<Pair<NaturalNumber, NaturalNumber>> episodes = this.seriesMap.lookup(seriesName);
        boolean found = false;
        for (int i = 0; i < episodes.size(); i++) {
            Pair<NaturalNumber, NaturalNumber> episode = episodes.get(i);
            if (episode.key().toInt() == episodeNumber) {
                episode.value().setFromInt(rating);
                found = true;
                break;
            }
        }
        if (!found) {
            episodes.add(new Pair<>(new NaturalNumber2(episodeNumber), new NaturalNumber2(rating)));
        }
    }

    /**
     * Returns a sequence of all series names being tracked.
     */
    protected Sequence<String> getAllSeriesNames() {
        Sequence<String> seriesNames = new Sequence1L<>();
        for (Map.Pair<String, List<Pair<NaturalNumber, NaturalNumber>>> entry : this.seriesMap) {
            seriesNames.add(entry.key());
        }
        return seriesNames;
    }

    /**
     * Creates a new instance of the tracker with a copy of the current state.
     */
    protected AnimeEpisodeTracker createNewRep() {
        AnimeEpisodeTracker newTracker = new AnimeEpisodeTracker();
        for (Map.Pair<String, List<Pair<NaturalNumber, NaturalNumber>>> entry : this.seriesMap) {
            List<Pair<NaturalNumber, NaturalNumber>> newList = new List1L<>();
            for (Pair<NaturalNumber, NaturalNumber> episode : entry.value()) {
                newList.add(new Pair<>(new NaturalNumber2(episode.key().toInt()), new NaturalNumber2(episode.value().toInt())));
            }
            newTracker.seriesMap.add(entry.key(), newList);
        }
        return newTracker;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("AnimeEpisodeTracker: ");
        for (String seriesName : this.getAllSeriesNames()) {
            sb.append(seriesName).append("; ");
        }
        return sb.toString().trim();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof AnimeEpisodeTracker)) return false;
        AnimeEpisodeTracker that = (AnimeEpisodeTracker) obj;
        return this.seriesMap.equals(that.seriesMap);
    }

    @Override
    public int hashCode() {
        return this.seriesMap.hashCode();
    }

    
}
