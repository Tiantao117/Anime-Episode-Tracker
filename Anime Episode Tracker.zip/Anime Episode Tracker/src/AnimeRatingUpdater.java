import components.map.Map;
import components.map.Map1L;
import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.sequence.Sequence;
import components.sequence.Sequence1L;

public class AnimeRatingUpdater {

    private AnimeEpisodeTracker tracker;

    public AnimeRatingUpdater() {
        tracker = new AnimeEpisodeTracker();
    }

    public void updateRating(String seriesName, int episodeNumber, int newRating) {
        if (tracker.checkIfWatched(seriesName, episodeNumber)) {
            tracker.setEpisodeRating(seriesName, episodeNumber, newRating);
            System.out.println("Updated rating for " + seriesName + " Episode " + episodeNumber + " to " + newRating);
        } else {
            System.out.println(seriesName + " Episode " + episodeNumber + " has not been watched yet.");
        }
    }

    public static void main(String[] args) {
        AnimeRatingUpdater updater = new AnimeRatingUpdater();
        updater.updateRating("One Punch Man", 1, 10);
        updater.updateRating("One Punch Man", 2, 9);  // Assume episode 2 has not been watched yet
    }
}
