import components.map.Map;
import components.map.Map1L;
import components.naturalnumber.NaturalNumber;
import components.naturalnumber.NaturalNumber2;
import components.sequence.Sequence;
import components.sequence.Sequence1L;

public class AnimeWatchlistManager {

    private AnimeEpisodeTracker tracker;

    public AnimeWatchlistManager() {
        tracker = new AnimeEpisodeTracker();
    }

    public void addSeries(String seriesName, int episodeNumber, int rating) {
        tracker.setEpisodeRating(seriesName, episodeNumber, rating);
    }

    public void printWatchlist() {
        Sequence<String> seriesNames = tracker.getAllSeriesNames();
        System.out.println("Anime Watchlist:");
        for (String name : seriesNames) {
            System.out.println("Series: " + name);
        }
    }

    public static void main(String[] args) {
        AnimeWatchlistManager manager = new AnimeWatchlistManager();
        manager.addSeries("My Hero Academia", 1, 8);
        manager.addSeries("My Hero Academia", 2, 9);
        manager.addSeries("Demon Slayer", 1, 10);
        manager.addSeries("Steins Gate", 1, 10);

        manager.printWatchlist();
    }
}
