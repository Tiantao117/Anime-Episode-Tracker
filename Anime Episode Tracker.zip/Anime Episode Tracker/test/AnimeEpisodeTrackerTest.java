import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class AnimeEpisodeTrackerTest {
    
    private AnimeEpisodeTracker tracker;

    @Before
    public void setUp() {
        tracker = new AnimeEpisodeTracker();
    }

    @Test
    public void testCheckIfWatchedNoSeries() {
        assertFalse(tracker.checkIfWatched("NonExistent", 1));
    }

    @Test
    public void testCheckIfWatchedNoEpisode() {
        tracker.setEpisodeRating("One Piece", 1, 8);
        assertFalse(tracker.checkIfWatched("One Piece", 2));
    }

    @Test
    public void testCheckIfWatchedExists() {
        tracker.setEpisodeRating("Naruto", 1, 7);
        assertTrue(tracker.checkIfWatched("Naruto", 1));
    }

    @Test
    public void testSetEpisodeRatingNewSeries() {
        tracker.setEpisodeRating("Bleach", 1, 9);
        assertTrue(tracker.checkIfWatched("Bleach", 1));
    }

    @Test
    public void testUpdateEpisodeRating() {
        tracker.setEpisodeRating("Attack on Titan", 1, 7);
        tracker.setEpisodeRating("Attack on Titan", 1, 8);
        assertEquals(8, tracker.seriesMap.lookup("Attack on Titan").get(0).value().toInt());
    }

    @Test
    public void testGetAllSeriesNamesEmpty() {
        assertTrue(tracker.getAllSeriesNames().isEmpty());
    }

    @Test
    public void testGetAllSeriesNamesMultiple() {
        tracker.setEpisodeRating("DBZ", 1, 7);
        tracker.setEpisodeRating("Tokyo Ghoul", 1, 8);
        Sequence<String> names = tracker.getAllSeriesNames();
        assertTrue(names.contains("DBZ") && names.contains("Tokyo Ghoul"));
    }

    @Test
    public void testCreateNewRep() {
        tracker.setEpisodeRating("Jujutsu Kaisen", 1, 8);
        AnimeEpisodeTracker newTracker = tracker.createNewRep();
        newTracker.setEpisodeRating("Jujutsu Kaisen", 2, 9);
        assertFalse(tracker.checkIfWatched("Jujutsu Kaisen", 2));
        assertEquals(9, newTracker.seriesMap.lookup("Jujutsu Kaisen").get(1).value().toInt());
    }
}
